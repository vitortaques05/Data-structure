export interface IQueue {
    enqueue(item: string): void;
    dequeue(): string;
    size(): number;
    isFull(): boolean;
    }
    