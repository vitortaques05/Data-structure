export interface IStack {

    push(item: string): void;
    pop(): string;
    size(): number;
    isFull(): boolean;

}