import { IList } from "./iList";

export class List implements IList{

    itens: string [] = []

    add(item: string): void {
        this.itens.push(item)
    }

    remove(item:string): void {
        for (let i = 0; i < this.itens.length; i++) {
            if (this.itens[i] === item){
                this.itens.splice(i, 1);
                break;
            }
            
        }
    }

    get(index: number): string {
        if (index > 0 && index < this.itens.length){
            return this.itens[index];
        } else {
        throw new Error("indice não existe");    
        }
    }
    
    set(index: number, item: string): void {
        if (index > 0 && index < this.itens.length){
            this.itens[index] = item
        } else {
        throw new Error("indice não existe");    
        }
    }

    contains(item: string): boolean {
       return this.itens.includes(item)
    }

    size(): number {
        return this.itens.length
    }

    isEmpty(): boolean {
        if (this.itens.length === 0){
            return true
        } else {
            return false
        }
       
    }

}