import { IStack } from "./iStack";

export class Stack implements IStack {
    
    itens:string[] = []
    maxItens: number = 100

    push(item: string): void {
        if (! this.isFull()){
            this.itens.push(item);
        } else {
            throw new Error("Stack cheia :(");
        }
    }

    pop(): string {
        if (this.itens.length > 0){
            return this.itens.pop();
        } else {
            throw new Error("Array vazio");
        }
    }

    size(): number {
        return this.itens.length
    }

    isFull(): boolean {
        if (this.itens.length < this.maxItens){
            return true
        } else {
            return false
        }
    }

}