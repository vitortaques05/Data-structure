import { IQueue } from "./iQueue";

export class Queue implements IQueue {
    
    itens: string[] = []

    enqueue(item: string): void {
        this.itens.push(item);
    }

    dequeue(): string {
       if (this.itens.length > 0){
            return this.itens.shift()
       }
        
    }

    size(): number {
        return this.itens.length
    }
    
    isFull(): boolean {
        return false
    }

}