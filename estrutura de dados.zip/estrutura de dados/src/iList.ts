export interface IList {
    add(item: string): void;
    remove(item: string): void;
    get(index: number): void;
    set(index: number, item: string): void;
    contains(item: string): boolean;
    size(): number;
    isEmpty(): boolean;


}